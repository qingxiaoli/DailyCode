## Introduction
this script is to using Geodesic active contour algorithm with level set formula to implement image segmentation.

## Information
coder: Jie An 1601210097  
version: 20170317  
bug_submission: <pkuanjie@gmail.com>  
license: no license, everyone is free to use

## Run guide
this script is coded and tested on a machine below:  
OS: Arch Linux  
Kernel: x86_64 Linux 4.10.2-1-ARCH  
Shell: bash 4.4.12  
CPU: Intel Core i7-6700K @ 8x 4.2GHz   
GPU: GeForce GTX 1060 6GB  
RAM: 16003MiB  
MATLAB Version: R2016B(9.1.0.441655) 64-bit(glnxa64)

## Addition
for more information, pls call  
*+86 18811355492*